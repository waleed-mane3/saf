from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from auth_system.models import CustomUser
from django.contrib.auth import get_user_model

# this is responsible to show information about the user after decode it 
class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)

        # Add custom claims
        # there is user_id field hidden by default
        token['first_name'] = user.first_name
        token['last_name'] = user.last_name
        token['email_address'] = user.email
        token['user_type'] = user.user_type
        token['first_sign_in'] = user.first_sign_in
        # ...

        return token
    


