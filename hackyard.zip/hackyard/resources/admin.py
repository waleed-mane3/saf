from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from import_export.admin import ImportExportModelAdmin
from resources.models import Resource

@admin.register(Resource)
class ResourceExportImport(ImportExportModelAdmin):
    list_display = ['id', 'title','track']