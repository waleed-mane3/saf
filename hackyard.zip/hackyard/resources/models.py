from django.db import models


class Resource(models.Model):
    title = models.CharField(max_length=1000)
    description = models.TextField()
    link = models.TextField()
    track = models.CharField(max_length=500)
    image = models.ImageField(upload_to='resources/')

    # this date will never be updated
    created_at = models.DateTimeField(null=True, auto_now_add=True)
    # this date will change every time we update entry
    update_at = models.DateTimeField(null=True, auto_now=True)
