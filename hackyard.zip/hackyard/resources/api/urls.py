from django.urls import path
from resources.api.views import (
    all_resources,
    create_resource,
    update_resource,
    delete_resource
)


urlpatterns = [
    path('', all_resources.as_view(), name='all_resources'),
    path('create/', create_resource, name='create_resource'),
    path('update/<str:pk>/', update_resource, name='update_resource'),
    path('delete/<str:pk>/', delete_resource, name='delete_resource'),
]
