from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from resources.api.serializers import (
    GetAllResourcesSerializer,
    UpdateResourceSerializer,
    CreateResourceSerializer
)
from resources.models import Resource

from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import PageNumberPagination
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.generics import ListAPIView

from utils.utils import CustomPagination

# Get all Resources (beneficiary: user)
class all_resources(ListAPIView):
    queryset = Resource.objects.all()
    serializer_class = GetAllResourcesSerializer
    authentication_classes = (JWTAuthentication,)
    permission_classes = (IsAuthenticated,)
    pagination_class = CustomPagination


# # Get all Resource (beneficiary: )
# @api_view(['GET',])
# @permission_classes([IsAuthenticated])
# def all_resources(request):
#     resources = Resource.objects.all()
#     serializer = GetAllResourcesSerializer(resources, many=True)
#     return Response(serializer.data)


# Post New Resource (beneficiary: Admin)
@api_view(['POST',])
def create_resource(request):
    user = request.user
    data = {}

    if user.is_superuser:
        serializer = CreateResourceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            data['success'] = "You have created new resource successfully!"
            request_status = status.HTTP_201_CREATED
        else:
            data['error'] = serializer.errors
            request_status = status.HTTP_400_BAD_REQUEST 
    
    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"
            
    return Response(data=data, status=request_status)



# Update Resource (beneficiary: )
@api_view(['PUT',])
@permission_classes([IsAuthenticated])
def update_resource(request, pk):
    user = request.user
    data = {}
    
    if user.is_superuser:
        try:
            resource = Resource.objects.get(id=pk)
        except:
            data['error'] = "This resource is not existed with this id!"
            request_status = status.HTTP_404_NOT_FOUND
            return Response(data, status=request_status)


        serializer = UpdateResourceSerializer(resource, data=request.data)
        if serializer.is_valid():
            serializer.save()
            request_status = status.HTTP_200_OK
            data['success'] = "Resource has been updated successfully!"
        else:
            request_status = status.HTTP_400_BAD_REQUEST
            data['error'] = serializer.errors
    
    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"


    return Response(data, status=request_status)


# Delete Resource
@api_view(['DELETE',])
@permission_classes([IsAuthenticated])
def delete_resource(request, pk):
    user = request.user
    data = {}

    if user.is_superuser:
        try:
            resource = Resource.objects.get(id=pk)
        except Resource.DoesNotExist:
            data['error'] = "This resource is not existed with this id!"
            return Response(data=data, status=status.HTTP_404_NOT_FOUND)
        
        operation = resource.delete()
        if operation:
            data['success'] = "Resource has been deleted successfully!"
            request_status = status.HTTP_200_OK

        else:
            data["failure"] = "Deletion failed!"
            request_status = status.HTTP_501_NOT_IMPLEMENTED
    
    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"
    
    return Response(data=data, status=request_status)