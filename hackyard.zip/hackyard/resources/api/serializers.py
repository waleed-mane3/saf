from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from resources.models import Resource


# Get all Resources
class GetAllResourcesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Resource
        fields = '__all__'

# Post Resource
class CreateResourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Resource
        fields = '__all__'

# Update Resource
class UpdateResourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Resource
        fields = '__all__'
