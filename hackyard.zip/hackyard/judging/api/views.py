from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from judging.api.serializers import (
    CreateEvaluationSerializer,
    CreateJudgingSerializer,
)

from teaming.models import Team
from judging.models import Evaluation, Judging
from rest_framework.permissions import IsAuthenticated






# Create Evaluation
@permission_classes([IsAuthenticated])
@api_view(['POST'])
def create_evaluation(request):
    data = {}
    # to make the request data mutable
    # _mutable = request.data._mutable
    # request.data._mutable = True
    request.data['score'] = float(request.data['score'])/2
    # set mutable flag back
    # request.data._mutable = _mutable

    # final score
    current_score_entered = request.data['score']
    project_id = request.data['project']

    team_to_update = Team.objects.filter(id=project_id)
    all_evaluations = Evaluation.objects.all().filter(project=project_id).values_list('score', flat=True)
    evaluations_total_score = 0

    for evaluation in all_evaluations:
        eva = evaluation
        evaluations_total_score += eva
    evaluations_total_score += current_score_entered

    evals_len = len(all_evaluations)+1
    final_score = evaluations_total_score/evals_len
    decimal_final_score = "{:.4f}".format(final_score)

    team_to_update.update(eval_score=decimal_final_score)
    # final score

    serializer = CreateEvaluationSerializer(data=request.data)
    
    if serializer.is_valid():
        serializer.save()

        mentor_id = serializer.data['evaluator']
        team_id = serializer.data['project']

        team_to_update = Team.objects.filter(id=team_id)
        team = Team.objects.get(id=team_id)

        team_eval = team.eval_history
        if team_eval:
            eval_ls = team_eval['evaluators']
            eval_ls.append(mentor_id)
            mentor_dict = {'evaluators': eval_ls}
            team_to_update.update(eval_history=mentor_dict)
        else:
            eval_dict = {'evaluators': [mentor_id]}
            team_to_update.update(eval_history=eval_dict)
        
        data['success'] = "Team has been evaluated successfully!"
        request_status = status.HTTP_200_OK
    
    else:
        data['error'] = serializer.errors
        request_status = status.HTTP_400_BAD_REQUEST
    

    return Response(data=data, status=request_status)




# Create Judging 
@permission_classes([IsAuthenticated])
@api_view(['POST'])
def create_judging(request):
    data = {}

    # to make the request data mutable
    # _mutable = request.data._mutable
    # request.data._mutable = True
    request.data['score'] = float(request.data['score'])/5
    # set mutable flag back
    # request.data._mutable = _mutable


    # final score
    j_current_score_entered = request.data['score']
    project_id = request.data['project']

    j_team_to_update = Team.objects.filter(id=project_id)
    all_judgings = Judging.objects.all().filter(project=project_id).values_list('score', flat=True)
    judgings_total_score = 0
    for judging in all_judgings:
        jud = judging
        judgings_total_score += jud
    judgings_total_score += j_current_score_entered
    judgings_len = len(all_judgings)+1
    ju_final_score = judgings_total_score/judgings_len
    ju_decimal_final_score = "{:.4f}".format(ju_final_score)

    j_team_to_update.update(judging_score=ju_decimal_final_score)
    # final score

    serializer = CreateJudgingSerializer(data=request.data)
    
    if serializer.is_valid():
        serializer.save()

        judge_id = serializer.data['judge']
        team_id = serializer.data['project']

        team_to_update = Team.objects.filter(id=team_id)
        team = Team.objects.get(id=team_id)

        team_judge = team.judge_history
        if team_judge:
            judge_ls = team_judge['judges']
            judge_ls.append(judge_id)
            judge_dict = {'judges': judge_ls}
            team_to_update.update(judge_history=judge_dict)
        else:
            judge_dict = {'judges': [judge_id]}
            team_to_update.update(judge_history=judge_dict)
        
        data['success'] = "Team has been judged successfully!"
        request_status = status.HTTP_200_OK
    
    else:
        data['error'] = serializer.errors
        request_status = status.HTTP_400_BAD_REQUEST

    return Response(data = data, status=request_status)