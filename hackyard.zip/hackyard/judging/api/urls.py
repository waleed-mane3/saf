from django.urls import path
from judging.api.views import (
    create_evaluation,
    create_judging, 
)


urlpatterns = [
    path('create-evaluation/', create_evaluation, name='create_evaluation'),
    path('create-judging/', create_judging, name='create_judging'),
    # path('update-user/', update_user, name='update_user'),
    # path('change-password/', ChangePasswordView.as_view(), name='change_password'),
    # path('update/first-sign-in/', update_first_sign_in, name='update_first_sign_in'),
]
