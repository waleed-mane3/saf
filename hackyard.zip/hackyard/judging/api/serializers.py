from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from judging.models import Judging, Evaluation




class CreateEvaluationSerializer(serializers.ModelSerializer):

    class Meta:
        model = Evaluation
        fields = ('evaluator', 'project', 'score',)


class CreateJudgingSerializer(serializers.ModelSerializer):

    class Meta:
        model = Judging
        fields = ('judge', 'project', 'score',)