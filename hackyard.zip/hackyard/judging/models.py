from django.db import models
from auth_system.models import CustomUser
from teaming.models import Team
from django.utils.translation import gettext_lazy as _


class Evaluation(models.Model):
    evaluator = models.ForeignKey(CustomUser, verbose_name=_("Evaluator"), on_delete=models.SET_NULL, null=True)
    project = models.ForeignKey(Team, verbose_name=_("Project"), on_delete=models.SET_NULL, null=True)
    score = models.FloatField(blank=True, null=True, verbose_name=_("Score"), default=0)
    
    created_at = models.DateTimeField(null=True, auto_now_add=True)
    update_at = models.DateTimeField(null=True, auto_now=True)



class Judging(models.Model):
    judge = models.ForeignKey(CustomUser, verbose_name=_("Judge"), on_delete=models.SET_NULL, null=True)
    project = models.ForeignKey(Team, verbose_name=_("Project"), on_delete=models.SET_NULL, null=True)
    score = models.FloatField(blank=True, null=True, verbose_name=_("Score"), default=0)
    
    created_at = models.DateTimeField(null=True, auto_now_add=True)
    update_at = models.DateTimeField(null=True, auto_now=True)