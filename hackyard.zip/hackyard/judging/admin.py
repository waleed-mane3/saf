from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from judging.models import Evaluation, Judging


@admin.register(Evaluation)
class EvaluationImportExport(ImportExportModelAdmin):
    list_display = ['id', 'evaluator', 'project', 'score']


@admin.register(Judging)
class JudgingImportExport(ImportExportModelAdmin):
    list_display = ['id', 'judge', 'project', 'score']