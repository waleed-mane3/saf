from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from import_export.admin import ImportExportModelAdmin
from mentors.models import Mentor

@admin.register(Mentor)
class MentorExportImport(ImportExportModelAdmin):
    list_display = ['id', 'name','role']