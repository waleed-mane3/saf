from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from mentors.api.serializers import (
    GetAllMentorsSerializer,
    UpdateMentorSerializer,
    CreateMentorSerializer
)
from mentors.models import Mentor

from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import PageNumberPagination
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.generics import ListAPIView

from utils.utils import CustomPagination

##custom pagination##
# class CustomPagination(PageNumberPagination):

#     def get_paginated_response(self, data):
#         return Response({
#             'links': {
#                'next': self.get_next_link(),
#                'previous': self.get_previous_link()
#             },
#             'count': self.page.paginator.count,
#             'total_pages': self.page.paginator.num_pages,
#             'results': data
#         })




# Get all Mentor (beneficiary: user)
class all_mentors(ListAPIView):
    queryset = Mentor.objects.all()
    serializer_class = GetAllMentorsSerializer
    authentication_classes = (JWTAuthentication,)
    permission_classes = (IsAuthenticated,)
    pagination_class = CustomPagination


# Get all Mentor (beneficiary: user)
# @api_view(['GET',])
# # @permission_classes([IsAuthenticated])
# def all_mentors(request):
#     mentors = Mentor.objects.all()
#     serializer = GetAllMentorsSerializer(mentors, many=True)
#     return Response(serializer.data)







# Post New Mentor (beneficiary: super user)
@api_view(['POST',])
def create_mentor(request):
    user = request.user
    data = {}

    if user.is_superuser:
        serializer = CreateMentorSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            data['success'] = "You have created new mentor successfully!"
            request_status = status.HTTP_201_CREATED
        else:
            data['error'] = serializer.errors
            request_status = status.HTTP_400_BAD_REQUEST 
                
        return Response(data=data, status=request_status)

    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"

    return Response(data=data, status=request_status)

# Update Mentor (beneficiary: super user)
@api_view(['PUT',])
@permission_classes([IsAuthenticated])
def update_mentor(request, pk):
    user = request.user
    data = {}
    
    if user.is_superuser:
        try:
            mentor = Mentor.objects.get(id=pk)
        except:
            data['error'] = "This Mentor is not existed with this id!"
            request_status = status.HTTP_404_NOT_FOUND
            return Response(data, status=request_status)


        serializer = UpdateMentorSerializer(mentor, data=request.data)
        if serializer.is_valid():
            serializer.save()
            request_status = status.HTTP_200_OK
            data['success'] = "Mentor has been updated successfully!"
        else:
            request_status = status.HTTP_400_BAD_REQUEST
            data['error'] = serializer.errors
    
    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"


    return Response(data, status=request_status)


# Delete Mentor (beneficiary: super user)
@api_view(['DELETE',])
@permission_classes([IsAuthenticated])
def delete_mentor(request, pk):
    user = request.user
    data = {}

    if user.is_superuser:
        try:
            mentor = Mentor.objects.get(id=pk)
        except Mentor.DoesNotExist:
            data['error'] = "This Mentor is not existed with this id!"
            return Response(data=data, status=status.HTTP_404_NOT_FOUND)
        
        operation = mentor.delete()
        if operation:
            data['success'] = "Mentor has been deleted successfully!"
            request_status = status.HTTP_200_OK

        else:
            data["failure"] = "Deletion failed!"
            request_status = status.HTTP_501_NOT_IMPLEMENTED
    
    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"
    
    return Response(data=data, status=request_status)