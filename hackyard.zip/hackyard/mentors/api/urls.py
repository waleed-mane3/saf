from django.urls import path
from mentors.api.views import (
    all_mentors,
    create_mentor,
    update_mentor,
    delete_mentor
)


urlpatterns = [
    path('', all_mentors.as_view(), name='all_mentor'),
    path('create/', create_mentor, name='create_mentor'),
    path('update/<str:pk>/', update_mentor, name='update_mentor'),
    path('delete/<str:pk>/', delete_mentor, name='delete_mentor'),
]
