from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from mentors.models import Mentor


# Get all Mentors
class GetAllMentorsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mentor
        fields = '__all__'

# Post Mentor
class CreateMentorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mentor
        fields = '__all__'

# Update Mentor
class UpdateMentorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mentor
        fields = '__all__'
