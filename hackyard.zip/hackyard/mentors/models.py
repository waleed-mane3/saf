from django.db import models
# from jsonfield import JSONField



class Mentor(models.Model):
    name = models.CharField(max_length=1000)
    bio = models.TextField()
    role = models.CharField(max_length=1000, null=True, blank=True)
    image = models.ImageField(upload_to='mentors/')
    book = models.TextField(null=True, blank=True)

    # this date will never be updated
    created_at = models.DateTimeField(null=True, auto_now_add=True)
    # this date will change every time we update entry
    update_at = models.DateTimeField(null=True, auto_now=True)

