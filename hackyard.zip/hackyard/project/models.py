from django.db import models
from django.core.validators import FileExtensionValidator
from auth_system.models import CustomUser
from django.db.models.signals import post_save
from django.dispatch import receiver

from django.core.exceptions import ValidationError

def file_size(value): # add this to some file where you can import it from
    limit = 100 * 1024 * 1024
    if value.size > limit:
        raise ValidationError('File too large. Size should not exceed 2 MB.')



class Project(models.Model):
    name = models.CharField(max_length=1000)
    description = models.TextField()
    track = models.CharField(max_length=500, null=True, blank=True)
    link = models.TextField(null=True, blank=True)
    # image = models.ImageField(upload_to='resources/')
    
    project_file = models.FileField(upload_to='projects/', null=True, validators=[FileExtensionValidator(allowed_extensions=['zip'],), file_size])
    # project_file = models.FileField(upload_to='projects/', null=True, validators=[file_size])
    user = models.OneToOneField(CustomUser, on_delete= models.CASCADE)

    # this date will never be updated
    created_at = models.DateTimeField(null=True, auto_now_add=True)
    # this date will change every time we update entry
    update_at = models.DateTimeField(null=True, auto_now=True)



@receiver(post_save, sender=CustomUser)
def create_user_project(sender, instance, created, **kwargs):
    if created:
        Project.objects.create(user=instance)


@receiver(post_save, sender=CustomUser)
def save_user_role(sender, instance, **kwargs):
    instance.project.save()