from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from import_export.admin import ImportExportModelAdmin
from project.models import Project

@admin.register(Project)
class ProjectExportImport(ImportExportModelAdmin):
    list_display = ['id', 'name', 'user']