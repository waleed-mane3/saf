from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from project.models import Project


# Get all Projects
class GetProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = '__all__'

# Post Resource
class CreateProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = '__all__'

# Update Resource
class UpdateProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = ['name', 'description', 'link', 'project_file']
