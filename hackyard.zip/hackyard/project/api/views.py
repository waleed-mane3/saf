from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from project.api.serializers import (
    UpdateProjectSerializer,
    CreateProjectSerializer,
    GetProjectSerializer
)
from project.models import Project

# from rest_framework.permissions import IsAuthenticated
# from rest_framework.pagination import PageNumberPagination
# from rest_framework_simplejwt.authentication import JWTAuthentication
# from rest_framework.generics import ListAPIView



# # Get all Resource (beneficiary: )
# @api_view(['GET',])
# @permission_classes([IsAuthenticated])
# def all_resources(request):
#     resources = Resource.objects.all()
#     serializer = GetAllResourcesSerializer(resources, many=True)
#     return Response(serializer.data)


# Post New Resource (beneficiary: Admin)
@api_view(['GET',])
@permission_classes([IsAuthenticated])
def get_project(request):
    user = request.user
    data = {}

    try:
        project = user.project
    except:
        data['error'] = "This Project is not existed for this user"
        request_status = status.HTTP_404_NOT_FOUND
        return Response(data, status=request_status)
    
    print(project)

    serializer = GetProjectSerializer(project)
    data = serializer.data
    request_status = status.HTTP_200_OK
            
    return Response(data=data, status=request_status)




# Post New Resource (beneficiary: )
@api_view(['POST',])
def create_project(request):
    data = {}

    serializer = CreateProjectSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        data['success'] = "You have created new project successfully!"
        request_status = status.HTTP_201_CREATED
    else:
        data['error'] = serializer.errors
        request_status = status.HTTP_400_BAD_REQUEST 
    
            
    return Response(data=data, status=request_status)


from rest_framework.decorators import api_view
from rest_framework.decorators import parser_classes
from rest_framework.parsers import FormParser, MultiPartParser

# Update Resource (beneficiary: )
@api_view(['PUT',])
@permission_classes([IsAuthenticated])
def update_project(request, pk):
    print(request.data)
    user = request.user
    data = {}
    
    if user.is_superuser:
        try:
            resource = Project.objects.get(id=pk)
        except:
            data['error'] = "This resource is not existed with this id!"
            request_status = status.HTTP_404_NOT_FOUND
            return Response(data, status=request_status)


        serializer = UpdateProjectSerializer(resource, data=request.data)
        if serializer.is_valid():
            serializer.save()
            request_status = status.HTTP_200_OK
            data['success'] = "Resource has been updated successfully!"
        else:
            request_status = status.HTTP_400_BAD_REQUEST
            data['error'] = serializer.errors
    
    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"


    return Response(data, status=request_status)




# from django.http import Http404
# from rest_framework.views import APIView

# class UpdateProject(APIView):
#     """
#     Retrieve, update or delete a snippet instance.
#     """
#     parser_classes = (MultiPartParser, FormParser,)


#     def get_object(self, pk):
#         try:
#             return Project.objects.get(id=pk)
#         except Project.DoesNotExist:
#             raise Http404


#     def put(self, request, pk, format=None):
#         project = self.get_object(pk)
#         serializer = UpdateProjectSerializer(project, data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)




# class UpdateProject(APIView):
    
#     parser_classes = (FormParser, MultiPartParser)

#     def post(self, request, format=None):
#         return Response({'received data': request.data})