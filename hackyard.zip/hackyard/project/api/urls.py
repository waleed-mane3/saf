from webbrowser import get
from django.urls import path
from project.api.views import (
    create_project,
    update_project,
    get_project,
)


urlpatterns = [
    path('user-project/', get_project, name='project'),
    path('create/', create_project, name='create_project'),
    path('update/<str:pk>/', update_project, name='update_project'),
]
