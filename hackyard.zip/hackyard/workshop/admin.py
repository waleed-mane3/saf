from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from import_export.admin import ImportExportModelAdmin
from workshop.models import Workshop

@admin.register(Workshop)
class WorkshopExportImport(ImportExportModelAdmin):
    list_display = ['id', 'title', 'instructor', 'status','category', 'start', 'end']