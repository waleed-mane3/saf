from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from workshop.api.serializers import (
    GetAllWorkshopsSerializer,
    UpdateWorkshopSerializer,
    CreateWorkshopSerializer
)
from workshop.models import Workshop


from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import PageNumberPagination
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.generics import ListAPIView

from utils.utils import CustomPagination

# Get all Workshop (beneficiary: user)
class all_workshops(ListAPIView):
    queryset = Workshop.objects.all()
    serializer_class = GetAllWorkshopsSerializer
    authentication_classes = (JWTAuthentication,)
    permission_classes = (IsAuthenticated,)
    pagination_class = CustomPagination


# # Get all Workshops (beneficiary: user)
# @api_view(['GET',])
# @permission_classes([IsAuthenticated])
# def all_workshops(request):
#     workshops = Workshop.objects.all()
#     serializer = GetAllWorkshopsSerializer(workshops, many=True)
#     return Response(serializer.data)


# Post New Workshop (beneficiary: super user)
@api_view(['POST',])
def create_workshop(request):
    user = request.user
    data = {}

    if user.is_superuser:
        serializer = CreateWorkshopSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            data['success'] = "You have created new workshop successfully!"
            request_status = status.HTTP_201_CREATED
        else:
            data['error'] = serializer.errors
            request_status = status.HTTP_400_BAD_REQUEST 
    
    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"
            
    return Response(data=data, status=request_status)



# Update Workshop (beneficiary: super user)
@api_view(['PUT',])
@permission_classes([IsAuthenticated])
def update_workshop(request, pk):
    user = request.user
    data = {}
    
    if user.is_superuser:
        try:
            workshop = Workshop.objects.get(id=pk)
        except:
            data['error'] = "This workshop is not existed with this id!"
            request_status = status.HTTP_404_NOT_FOUND
            return Response(data, status=request_status)


        serializer = UpdateWorkshopSerializer(workshop, data=request.data)
        if serializer.is_valid():
            serializer.save()
            request_status = status.HTTP_200_OK
            data['success'] = "Workshop has been updated successfully!"
        else:
            request_status = status.HTTP_400_BAD_REQUEST
            data['error'] = serializer.errors
    
    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"

    return Response(data, status=request_status)


# Delete Workshop (beneficiary: super user)
@api_view(['DELETE',])
@permission_classes([IsAuthenticated])
def delete_workshop(request, pk):
    user = request.user
    data = {}

    if user.is_superuser:
        try:
            workshop = Workshop.objects.get(id=pk)
        except Workshop.DoesNotExist:
            data['error'] = "This Mentor is not existed with this id!"
            return Response(data=data, status=status.HTTP_404_NOT_FOUND)
        
        operation = workshop.delete()
        if operation:
            data['success'] = "Workshop has been deleted successfully!"
            request_status = status.HTTP_200_OK

        else:
            data["failure"] = "Deletion failed!"
            request_status = status.HTTP_501_NOT_IMPLEMENTED
    
    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"
    
    return Response(data=data, status=request_status)