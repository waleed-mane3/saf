from django.urls import path
from workshop.api.views import (
    all_workshops,
    create_workshop,
    update_workshop,
    delete_workshop
)


urlpatterns = [
    path('', all_workshops.as_view(), name='all_workshops'),
    path('create/', create_workshop, name='create_workshop'),
    path('update/<str:pk>/', update_workshop, name='update_workshop'),
    path('delete/<str:pk>/', delete_workshop, name='delete_workshop'),
]
