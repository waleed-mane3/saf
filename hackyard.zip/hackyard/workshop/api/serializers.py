from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from workshop.models import Workshop


# Get all Workshops
class GetAllWorkshopsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Workshop
        fields = '__all__'

# Post Mentor
class CreateWorkshopSerializer(serializers.ModelSerializer):
    class Meta:
        model = Workshop
        fields = '__all__'

# Update Mentor
class UpdateWorkshopSerializer(serializers.ModelSerializer):
    class Meta:
        model = Workshop
        fields = '__all__'
