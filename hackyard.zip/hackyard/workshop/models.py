from django.db import models
# from jsonfield import JSONField
from django.utils import timezone


class Workshop(models.Model):
    STATUS_CHOICES = [
        ('pre-recorded', 'pre-recorded'),
        ('youtube', 'youtube'),
        ('live', 'live'),
    ]

    title = models.CharField(max_length=1000)
    description = models.TextField()
    link = models.TextField(blank=True, null=True)
    instructor = models.CharField(max_length=500)
    status = models.CharField(choices=STATUS_CHOICES, max_length=500, null=True, blank=True)
    category = models.CharField(max_length=500)
    start = models.DateTimeField(default=timezone.now)
    end = models.DateTimeField(default=timezone.now)
    image = models.ImageField(upload_to='workshops/')

    # this date will never be updated
    created_at = models.DateTimeField(null=True, auto_now_add=True)
    # this date will change every time we update entry
    update_at = models.DateTimeField(null=True, auto_now=True)
