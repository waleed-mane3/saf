from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from preference.api.views import get_health

# Swagger 
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi


# Swagger
schema_view = get_schema_view(
   openapi.Info(
      title="Hackyard APIs",
      default_version='v1',
      description="API Documentation for Hackyard Platform",
      terms_of_service="",
      contact=openapi.Contact(email=""),
      license=openapi.License(name=""),
   ),
   public=True,
   permission_classes=[permissions.AllowAny],
)


urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/auth/', include('auth_system.api.urls')),
    path('api/agenda/', include('agenda.api.urls')),
    path('api/mentors/', include('mentors.api.urls')),
    path('api/workshops/', include('workshop.api.urls')),
    path('api/resources/', include('resources.api.urls')),
    path('api/account/', include('account.api.urls')),
    path('api/teaming/', include('teaming.api.urls')),
    path('api/project/', include('project.api.urls')),
    path('api/settings/', include('preference.api.urls')),
    path('api/judging/', include('judging.api.urls')),
    path('api/health/', get_health),
    # Swagger 
    path('', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
