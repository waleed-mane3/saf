from storages.backends.s3boto3 import S3Boto3Storage

class MediaStorage(S3Boto3Storage):
    # bucket_name = 'hackyard-static'
    # custom_domain = 'hackyard-static.s3-eu-west-1.amazonaws.com'
    location = 'media'
    default_acl = 'public-read'
    file_overwrite = True
    custom_domain = False
