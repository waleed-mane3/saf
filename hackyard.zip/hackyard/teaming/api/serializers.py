from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from teaming.models import Request, Team

# use this to get all teams and one team 
class GetAllTeamsSerializer(serializers.ModelSerializer):

    class Meta:
        model = Team
        fields = '__all__'

# Post Request
class CreateRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = Request
        fields = ['receiver_email', 'requester_email']
    

class UserRequestsSerializer(serializers.ModelSerializer):

    class Meta:
        model = Request
        fields = ['id', 'requester_email', 'receiver_email', 'status']



class AcceptRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = Request
        fields = ('status',)




