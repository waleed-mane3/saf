from django.urls import path
from teaming.api.views import (
   create_request,
   user_requests,
   accept_request,
   all_teams,
   get_team
)


urlpatterns = [
    path('teams/', all_teams, name='all_teams'),
    path('team/<str:pk>/', get_team, name='get_team'),
    path('request/', create_request, name='teaming_request'),
    path('user-requests/', user_requests, name='user-requests'),
    path('accept-request/', accept_request, name='accept-request'),
    # path('user/<str:pk>/', user_info, name='user_info'),
    # path('update-user/', update_user, name='update_user'),
    # path('change-password/', ChangePasswordView.as_view(), name='change_password'),
    # path('update/first-sign-in/', update_first_sign_in, name='update_first_sign_in'),
]
