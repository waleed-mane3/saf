from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from teaming.api.serializers import (
    CreateRequestSerializer,
    AcceptRequestSerializer,
    UserRequestsSerializer,
    GetAllTeamsSerializer
)
from teaming.models import Team, Request

from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import PageNumberPagination
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.generics import ListAPIView

from utils.utils import CustomPagination
from auth_system.models import CustomUser
from utils.emails import request_email, accept_email, reject_email
from django.db.models import Q


# Get all Teams (beneficiary: user)
@api_view(['GET',])
@permission_classes([IsAuthenticated])
def all_teams(request):
    teams = Team.objects.all()
    serializer = GetAllTeamsSerializer(teams, many=True)
    return Response(serializer.data)


# Get one Team (beneficiary: user)
@api_view(['GET',])
@permission_classes([IsAuthenticated])
def get_team(request, pk):
    data = {}

    try:
        team = Team.objects.get(id=pk)
    except:
        data['error'] = "This Team is not existed with this id!"
        request_status = status.HTTP_404_NOT_FOUND
        return Response(data, status=request_status)

    serializer = GetAllTeamsSerializer(team)
    data = serializer.data
    request_status = status.HTTP_200_OK

    return Response(data=data, status=request_status)




# Create Request View
@permission_classes([IsAuthenticated])
@api_view(['POST'])
def create_request(request):
    user = request.user
    data = {}

    requester_email = user.email
    requester_user = user
    receiver_email = request.data['receiver_email'].strip()

    try:
        receiver_user = CustomUser.objects.get(email=receiver_email)
        team_exist = receiver_user.team
        role = receiver_user.user_type

        # 0
        ####### Start check if you sent request to this member ####
        try:
            existance_request = Request.object.filter(Q(receiver_email=receiver_email) & Q(requester_email=requester_email))
            data['error'] = "you have already sent a request to this member!"
            request_status = status.HTTP_400_BAD_REQUEST
            return Response(data=data, status=request_status)
        except:
            pass
        ####### End check if you sent request to this member ######

        # 1
        ####### Start check if member is part of your team ####
        if receiver_user.team and requester_user.team == receiver_user.team and receiver_email != receiver_email:
            data['error'] = "This member is already in your team!"
            request_status = status.HTTP_400_BAD_REQUEST
            return Response(data=data, status=request_status)
        ####### End check if member is part of your team ######

        # 2
        ####### Start check if this requester_email and receiver_email existed in Requests Table ##
        try:
            receiver_existance = Request.objects.filter(requester_email=requester_email).filter(receiver_email=receiver_email).first()
            if receiver_existance:
                data['error'] = "You have sent request to this user before!"
                request_status = status.HTTP_400_BAD_REQUEST
                return Response(data=data, status=request_status)
        except Exception:
            pass
        ####### End check if this requester_email and receiver_email existed in Requests Table ##


    except:
        data['error'] = "Requested user not found!"
        request_status = status.HTTP_400_BAD_REQUEST
        return Response(data=data, status=request_status)
        

    ##### Start check if member send to himself #####
    if requester_email == receiver_email:
        data['error'] = "You can't send an invitation to yourself!"
        request_status = status.HTTP_400_BAD_REQUEST
        return Response(data=data, status=request_status)
    #### End check if member send to himself ########

    serializer = CreateRequestSerializer(data=request.data)

    # if serializer.method == 'POST':
    if serializer.is_valid():
        if role == "participant":
            if team_exist == None:
                serializer.save()

                # Start send Email ################################
                requester_name = requester_user.first_name
                receiver_name = receiver_user.first_name
                receiver_email = receiver_user.email

                try:
                    request_email(receiver_email, receiver_name, requester_name)
                    data['success'] = "Request has been sent successfully!"
                    request_status = status.HTTP_200_OK

                except:
                    pass
                # End Send Email ############################

            else:
                data['error'] = "This member belongs to a team!"
                request_status = status.HTTP_400_BAD_REQUEST

        else:
            data['error'] = "This member is not a participant!"
            request_status = status.HTTP_400_BAD_REQUEST

    return Response(data=data, status=request_status)




@permission_classes([IsAuthenticated])
@api_view(['GET'])
def user_requests(request):
    user = request.user
    data = {}

    try:
        requests = Request.objects.filter(receiver_email=user.email).filter(status="pending")
    except Request.DoesNotExist:
        data['error'] = "no requests available!"
        request_status = status.HTTP_404_NOT_FOUND
    

    serializer = UserRequestsSerializer(requests, many=True)
    data = serializer.data
    request_status = status.HTTP_200_OK

    return Response(data=data, status=request_status)



# Accept or Reject Request
@permission_classes([IsAuthenticated])
@api_view(['PUT', ])
def accept_request(request):

    user = request.user
    data = {}

    # data
    receiver_email = request.data['receiver_email']
    requester_email = request.data['requester_email']
    req_status = request.data['status']

    # member receiver
    receiver_user_to_update = CustomUser.objects.filter(email=receiver_email)
    receiver_user = CustomUser.objects.filter(email=receiver_email).first()
    
    # member requester
    requester_user_to_update = CustomUser.objects.filter(email=requester_email)
    requester_user = CustomUser.objects.filter(email=requester_email).first()
    requester_team = requester_user.team

    # If members of the team more than give message
    if requester_user.team:
        try:
            users_of_team = CustomUser.objects.filter(team=requester_user.team)
            count_of_users = users_of_team.count()

            if count_of_users >= 3:
                request_to_delete = Request.objects.filter(requester_email=requester_email).filter(receiver_email=receiver_email)
                request_to_delete.delete()
                data['error'] = "This team is complete!"
                request_status = status.HTTP_400_BAD_REQUEST     
        except:
            pass
    #### end the capacity of the team###


    try:
        the_request = Request.objects.filter(receiver_email=receiver_email).filter(requester_email=requester_email).first()
    except Request.DoesNotExist:
        data['error'] = "This team is complete!"
        request_status = status.HTTP_404_NOT_FOUND
        return Response(data=data, status=request_status)

    if request.method == 'PUT':
        serializer = AcceptRequestSerializer(the_request, data=request.data)

        if serializer.is_valid():
            serializer.save()

            # here to add new member to a team or,
            # create new team if the member request is without team and add both of the members to the team

            if req_status == "accepted":
                if requester_team:
                    team = requester_team
                    receiver_user_to_update.update(team=team) # ????
                if requester_team == None:
                    # create new team
                    new_team = Team.objects.create(team_name=f"{requester_user.first_name} Team")
                    # assgin this new team for both users
                    receiver_user_to_update.update(team=new_team)
                    requester_user_to_update.update(team=new_team)
               

                data['success'] = "The request has been accepted successfully!"
                # requester_user_after_update = CustomUser.objects.filter(email=requester_email).first()
                # Send Email
                requester_name = requester_user.first_name
                receiver_name = receiver_user.first_name
                requester_email = requester_user.email

                try:
                    accept_email(requester_email, requester_name, receiver_name)
                    pass
                except Exception:
                    pass
                # End Send Email
                return Response(data=data)

            else:

                data['success'] = "The request has been rejected successfully!"
                # Send Email
                requester_name = requester_user.first_name
                receiver_name = receiver_user.first_name
                requester_email = requester_user.email
        
                try:
                    reject_email(requester_email, requester_name, receiver_name)
                    pass
                except Exception:
                    pass
                # End Send Email

                # extra3
                # request to delete
                delete_request = Request.objects.filter(requester_email=requester_email, receiver_email=receiver_email).first()
                delete_request.delete()
                return Response(data=data)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
















# ##custom pagination##
# # class CustomPagination(PageNumberPagination):

# #     def get_paginated_response(self, data):
# #         return Response({
# #             'links': {
# #                'next': self.get_next_link(),
# #                'previous': self.get_previous_link()
# #             },
# #             'count': self.page.paginator.count,
# #             'total_pages': self.page.paginator.num_pages,
# #             'results': data
# #         })




# # Get all Mentor (beneficiary: user)
# class all_mentors(ListAPIView):
#     queryset = Mentor.objects.all()
#     serializer_class = GetAllMentorsSerializer
#     authentication_classes = (JWTAuthentication,)
#     permission_classes = (IsAuthenticated,)
#     pagination_class = CustomPagination


# # Get all Mentor (beneficiary: user)
# # @api_view(['GET',])
# # # @permission_classes([IsAuthenticated])
# # def all_mentors(request):
# #     mentors = Mentor.objects.all()
# #     serializer = GetAllMentorsSerializer(mentors, many=True)
# #     return Response(serializer.data)







# # Post New Mentor (beneficiary: super user)
# @api_view(['POST',])
# def create_mentor(request):
#     user = request.user
#     data = {}

#     if user.is_superuser:
#         serializer = CreateMentorSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             data['success'] = "You have created new mentor successfully!"
#             request_status = status.HTTP_201_CREATED
#         else:
#             data['error'] = serializer.errors
#             request_status = status.HTTP_400_BAD_REQUEST 
                
#         return Response(data=data, status=request_status)

#     else:
#         request_status = status.HTTP_401_UNAUTHORIZED
#         data['error'] = "You are not Authorized to proceed, you need higher permission!"

#     return Response(data=data, status=request_status)

# # Update Mentor (beneficiary: super user)
# @api_view(['PUT',])
# @permission_classes([IsAuthenticated])
# def update_mentor(request, pk):
#     user = request.user
#     data = {}
    
#     if user.is_superuser:
#         try:
#             mentor = Mentor.objects.get(id=pk)
#         except:
#             data['error'] = "This Mentor is not existed with this id!"
#             request_status = status.HTTP_404_NOT_FOUND
#             return Response(data, status=request_status)


#         serializer = UpdateMentorSerializer(mentor, data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             request_status = status.HTTP_200_OK
#             data['success'] = "Mentor has been updated successfully!"
#         else:
#             request_status = status.HTTP_400_BAD_REQUEST
#             data['error'] = serializer.errors
    
#     else:
#         request_status = status.HTTP_401_UNAUTHORIZED
#         data['error'] = "You are not Authorized to proceed, you need higher permission!"


#     return Response(data, status=request_status)


# # Delete Mentor (beneficiary: super user)
# @api_view(['DELETE',])
# @permission_classes([IsAuthenticated])
# def delete_mentor(request, pk):
#     user = request.user
#     data = {}

#     if user.is_superuser:
#         try:
#             mentor = Mentor.objects.get(id=pk)
#         except Mentor.DoesNotExist:
#             data['error'] = "This Mentor is not existed with this id!"
#             return Response(data=data, status=status.HTTP_404_NOT_FOUND)
        
#         operation = mentor.delete()
#         if operation:
#             data['success'] = "Mentor has been deleted successfully!"
#             request_status = status.HTTP_200_OK

#         else:
#             data["failure"] = "Deletion failed!"
#             request_status = status.HTTP_501_NOT_IMPLEMENTED
    
#     else:
#         request_status = status.HTTP_401_UNAUTHORIZED
#         data['error'] = "You are not Authorized to proceed, you need higher permission!"
    
#     return Response(data=data, status=request_status)