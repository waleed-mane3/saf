from django.db import models
from django.utils.translation import gettext_lazy as _
from django.core.validators import FileExtensionValidator
from django.core.exceptions import ValidationError



def file_size(value): # add this to some file where you can import it from
    limit = 10 * 1024 * 1024
    if value.size > limit:
        raise ValidationError('File too large. Size should not exceed 10 MB.')

def eval_mentor_default():
    return {"evaluators": []}

def eval_judge_default():
    return {"judges": []}

# Team Model
class Team(models.Model):

    SUBMISSION_STATUS_CHOICES = [
        ('pending', 'pending'),
        ('submitted', 'submitted'),
        ('evaluated', 'evaluated'),
        ('judged', 'judged')
    ]
    
    team_name = models.CharField(verbose_name=_("Team Name"), max_length=1000)
    project_name = models.CharField(blank=True, null=True, verbose_name=_("Project Name"), max_length=500, default="")
    brief = models.TextField(blank=True, null=True, verbose_name=_("Brief Description"))
    cover = models.ImageField(upload_to='cover', null=True, blank=True)
    link = models.TextField(blank=True, null=True, verbose_name=_("Video Link"))
    project_pdf = models.FileField(upload_to='projects/', null=True, validators=[FileExtensionValidator(allowed_extensions=['pdf'],), file_size], blank=True)
    project_ppt = models.FileField(upload_to='projects/', null=True, validators=[FileExtensionValidator(allowed_extensions=['pptx'],), file_size], blank=True)
    is_published = models.BooleanField(blank=True, verbose_name=_("Published"), default=False)  # new field

    submission_status = models.CharField(verbose_name=_("Submission Status"), choices=SUBMISSION_STATUS_CHOICES, max_length=300, default='pending', null=True, blank=True)
    eval_score = models.FloatField(blank=True, null=True, default=0)  # Total Evaluation Score
    judging_score = models.FloatField(blank=True, null=True, default=0)
    
    # top_50 = models.BooleanField(blank=True, verbose_name=_("Top 50"), default=False)  # new field

    eval_history = models.JSONField(null=True, blank=True, default=eval_mentor_default)
    judge_history = models.JSONField(null=True, blank=True, default=eval_judge_default)


    # Creation and Update Fields
    # this date will never be updated
    created_at = models.DateTimeField(null=True, auto_now_add=True)
    # this date will change every time we update entry
    update_at = models.DateTimeField(null=True, auto_now=True)

    # Displays
    DisplayFields = ['id', 'team_name', 'project_name', 'is_published', 'submission_status', 'eval_score', 'judging_score']
    SearchableFields = ['id', 'team_name', 'submission_status', 'project_name', 'track', 'eval_score', 'judging_score', 'final_score']
    FilterFields = ['is_published', 'team_name', 'project_name']

    def __str__(self):
        return str(self.team_name)




class Request(models.Model):
    REQUEST_STATUS_CHOICES = [
        ('pending', 'pending'),
        ('accepted', 'accepted'),
        ('rejected', 'rejected')
    ]
   
    requester_email = models.CharField(verbose_name=_("Requester email"), max_length=500, blank=True, null=True)
    receiver_email = models.CharField(verbose_name=_("Receiver email"), max_length=500, blank=True, null=True)
    # requester_team_id = models.CharField(blank=True, null=True, verbose_name=_("Request Team Id"), max_length=256)
    status = models.CharField(max_length=256, null=True, blank=True, choices=REQUEST_STATUS_CHOICES, default="pending")

    # Creation and Update Fields
    created_at = models.DateTimeField(null=True, auto_now_add=True)
    update_at = models.DateTimeField(null=True, auto_now=True)








# class Judging(models.Model):
#     name = models.CharField(max_length=1000)
#     bio = models.TextField()
#     role = models.CharField(max_length=1000, null=True, blank=True)
#     image = models.ImageField(upload_to='mentors/')
#     book = models.TextField(null=True, blank=True)

#     # this date will never be updated
#     created_at = models.DateTimeField(null=True, auto_now_add=True)
#     # this date will change every time we update entry
#     update_at = models.DateTimeField(null=True, auto_now=True)
