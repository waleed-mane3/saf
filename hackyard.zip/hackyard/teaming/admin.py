from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from teaming.models import Team, Request


@admin.register(Team)
class TeamImportExport(ImportExportModelAdmin):
    list_display = Team.DisplayFields
    search_fields = Team.SearchableFields
    list_filter = Team.FilterFields
    list_per_page = 50


@admin.register(Request)
class RequestImportExport(ImportExportModelAdmin):
    list_display = ['id', 'requester_email', 'receiver_email', 'status']