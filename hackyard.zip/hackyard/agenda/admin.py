from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from import_export.admin import ImportExportModelAdmin
from agenda.models import Agenda

@admin.register(Agenda)
class AgendaExportImport(ImportExportModelAdmin):
    list_display = ['id', 'title', 'description', 'start', 'end', 'status']
