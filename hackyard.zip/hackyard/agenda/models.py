from django.db import models
# import jsonfield
from auth_system.models import CustomUser
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone

class Agenda(models.Model):
    STATUS_CHOICES = [
        ('important', 'important'),
        ('normal', 'normal')
    ]

    title = models.CharField(max_length=500,)
    description = models.TextField(blank=True)
    start = models.DateTimeField(default=timezone.now)
    end = models.DateTimeField(default=timezone.now)
    status = models.CharField(choices=STATUS_CHOICES, max_length=500, blank=True, null=True)

    # this date will never be updated
    created_at = models.DateTimeField(null=True, auto_now_add=True)
    # this date will change every time we update entry
    update_at = models.DateTimeField(null=True, auto_now=True)