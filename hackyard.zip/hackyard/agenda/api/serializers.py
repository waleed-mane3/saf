from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from agenda.models import Agenda


# Get all agendas
class GetAllAgendasSerializer(serializers.ModelSerializer):
    class Meta:
        model = Agenda
        fields = '__all__'

# Post agenda
class CreateAgendaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Agenda
        fields = '__all__'

# Update agenda
class UpdateAgendaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Agenda
        fields = '__all__'
