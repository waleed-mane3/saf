from django.urls import path
from agenda.api.views import (
    all_agendas,
    create_agenda,
    update_agenda,
    delete_agenda
)


urlpatterns = [
    path('', all_agendas, name='all_agenda'),
    path('create/', create_agenda, name='create_agenda'),
    path('update/<str:pk>/', update_agenda, name='update_agenda'),
    path('delete/<str:pk>/', delete_agenda, name='delete_agenda'),
]
