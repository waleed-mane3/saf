from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from auth_system.models import CustomUser
from teaming.models import Team

############### user info #####################################
class GetUsersSerializer(serializers.ModelSerializer):

    class Meta:
        model = CustomUser
        fields = ('id', 'first_name', 'last_name', 'email',)


# Get User Info
class GetUserSerializer(serializers.ModelSerializer):

    team_members = serializers.SerializerMethodField()

    def get_team_members(self, obj):
        return self.context.get("members")

    class Meta:
        model = CustomUser
        fields = ['id', 'first_name', 'last_name', 'email', 'user_type', 'first_sign_in', 'team', 'team_members']
        depth = 1

################# end user info ###############################




# Update User
class UpdateUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ('first_name', 'last_name',)


class ChangePasswordSerializer(serializers.Serializer):
    model = CustomUser

    """
    Serializer for password change endpoint.
    """
    # old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)


# Update first sign in
class UpdateFirstSignInSerializer(serializers.ModelSerializer):

    class Meta:
        model = CustomUser
        fields = ('first_sign_in',)
