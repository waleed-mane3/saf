from django.urls import path
from account.api.views import (
    user_info,
    update_user,
    update_first_sign_in,
    ChangePasswordView
)


urlpatterns = [
    path('user/<str:pk>/', user_info, name='user_info'),
    path('update-user/', update_user, name='update_user'),
    path('change-password/', ChangePasswordView.as_view(), name='change_password'),
    path('update/first-sign-in/', update_first_sign_in, name='update_first_sign_in'),
]
