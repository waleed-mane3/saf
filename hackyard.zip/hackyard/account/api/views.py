from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from account.api.serializers import (
    GetUserSerializer,
    GetUsersSerializer,
    UpdateUserSerializer,
    UpdateFirstSignInSerializer
)
from auth_system.models import CustomUser
from rest_framework import generics
from account.api.serializers import ChangePasswordSerializer
from teaming.models import Team
from django.db.models import Q


# Get User Info (beneficiary: Super Admin)
@api_view(['GET',])
@permission_classes([IsAuthenticated])
def user_info(request, pk):
    data = {}

    try:
        user = CustomUser.objects.get(id=pk)
        try:
            all_members = user.team.customuser_set.filter(~Q(id=pk))
            members_serializer = GetUsersSerializer(all_members, many=True)
            team_members = {"members": members_serializer.data}
        except:
            team_members = {"members": []}


    except CustomUser.DoesNotExist:
        data['error'] = "This user is not existed with this id!"
        return Response(data=data, status=status.HTTP_404_NOT_FOUND)
    
    serializer = GetUserSerializer(user, context=team_members)
    request_status = status.HTTP_200_OK
    data = serializer.data
    
    return Response(data=data, status=request_status)


# Update User
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_user(request):
    user = request.user
    data = {}
    
    if request.method == 'PUT':

        serializer = UpdateUserSerializer(user, data=request.data)
        if serializer.is_valid():
            serializer.save()
            data['success'] = "User Updated Successfully!"
            request_status = status.HTTP_200_OK

            # password = request.data['password']
            # if password:
            #     user.set_password(password)
            #     user.save()
        
        else:
            request_status = status.HTTP_400_BAD_REQUEST
            data['error'] = serializer.errors
       
        return Response(data=data, status=request_status)


# Update User Password
class ChangePasswordView(generics.UpdateAPIView):
    """
    An endpoint for changing password.
    """
    serializer_class = ChangePasswordSerializer
    model = CustomUser
    permission_classes = (IsAuthenticated,)

    def get_object(self, queryset=None):
        obj = self.request.user
        return obj

    def update(self, request, *args, **kwargs):
        self.object = self.get_object()
        serializer = self.get_serializer(data=request.data)

        if serializer.is_valid():
            # Check old password
            # if not self.object.check_password(serializer.data.get("old_password")):
            #     return Response({"old_password": ["Wrong password."]}, status=status.HTTP_400_BAD_REQUEST)
            # set_password also hashes the password that the user will get
            self.object.set_password(serializer.data.get("new_password"))
            self.object.save()
            response = {
                'status': 'success',
                'code': status.HTTP_200_OK,
                'message': 'Password updated successfully',
                'data': []
            }

            return Response(response)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



# Update first sign in
@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def update_first_sign_in(request):
    user_id = request.user.id
    user = CustomUser.objects.filter(id=user_id)
    data = {}
    
    if request.method == 'PUT':

        operation = user.update(first_sign_in = False)
        
        if operation:
            data['success'] = "User Updated Successfully!"
            request_status = status.HTTP_200_OK

        else:
            data["failure"] = "Update failed!"
            request_status = status.HTTP_501_NOT_IMPLEMENTED

        return Response(data=data, status=request_status)
         # serializer = UpdateFirstSignInSerializer(user, data=request.data)
        # if serializer.is_valid():
        #     serializer.save()
        #     data['success'] = "User Updated Successfully!"
        #     request_status = status.HTTP_200_OK
        
        # else:
        #     request_status = status.HTTP_400_BAD_REQUEST
        #     data['error'] = serializer.errors
       
        # return Response(data=data, status=request_status)







