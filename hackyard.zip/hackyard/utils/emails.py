from mailersend import emails


def request_email(receiver_email, receiver_name, requester_name):
    
    api_key = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiMDM1NzM4YjM4MjQzOTM3YzkyNmEyMmMxMjI0OWQ2Njk5NjhhZWY1MmRkNDZjYjJlZGI4MGY4ZTJhZThmYmJmMDA5Y2FmODJmYTg3M2M1ODMiLCJpYXQiOjE2NTg0MzU2NDIuNDAxMjA1LCJuYmYiOjE2NTg0MzU2NDIuNDAxMjA5LCJleHAiOjQ4MTQxMDkyNDIuMzk3ODUxLCJzdWIiOiIzMTc5NyIsInNjb3BlcyI6WyJlbWFpbF9mdWxsIiwiZG9tYWluc19mdWxsIiwiYWN0aXZpdHlfZnVsbCIsImFuYWx5dGljc19mdWxsIiwidG9rZW5zX2Z1bGwiLCJ3ZWJob29rc19mdWxsIiwidGVtcGxhdGVzX2Z1bGwiLCJzdXBwcmVzc2lvbnNfZnVsbCIsInNtc19mdWxsIl19.YC8N_gH3ew2d2qa61S01lpH3_T4JR_vy6Xmg2QP3-4ClQ-qQqjkQ9DGez3EqsmZAg6M37lwNpk9EDrB4ZAu71TCybQ3tsN0IEQJkouSE_JRSYOTl96yRROKgBmHd7HG29QnZL0AojqGyzOG_kYbZQSWEOJLiySFfb4ddWfgLnqY0igCSuBI8EdoSvvafq7jZrq7dBF42H_40w5IolD-8KC9Qdsu0MRv1dPiIUNauNYxc8gHBa4ipH4muzf2sbaUbe2M80NxmsZldTuzHRH9Q2b8heu_JlFTRX_vBTLjJstKw49LA66y2FjuiiDcwN0vIKC45PVfWuzE7G1fRFQfdDWx-vBwp0uks0N1ac16zhhFi96m-uFuRZd9eex3w5C5fv6SDO8yHV9qzw0ld_sbfZxnVFqHP3AlmpYho7XP8eIrhZqmdOQYKiMrIjrxrR2qb_rjrs9QDA_lsNnrfTGdIPGvvmOXLxpgrQflVYDbxH1PCR_9hTNbBpJrcl7L2X7MjeIGaLrngSkudcP1vdFPZGfQpAAhl86zAPzZ5vXt7sLLE4IvyYuTpnFCCebz3UmzkXLhkjYBbglCn4ie0y_L05-4bjkSi-7f_Qo4F6vOkBi_vJZs0q_eU0qK3zwBx5DWiEW27tn-DQnthsASLIiQTo92f33ZX3OxMxkffZeT76f8"
    mailer = emails.NewEmail(api_key)

    # define an empty dict to populate with mail values
    mail_body = {}

    mail_from = {
        "name": "Tanween Platform",
        "email": "info@hackyard.io",
    }

    recipients = [
        {
            "name": f"{receiver_name}",
            "email": f"{receiver_email}",
        }
    ]

    variables = [
        {
            "email": f"{receiver_email}",
            "substitutions": [
                {
                    "var": "requester_name",
                    "value": f"{requester_name}"
                },
                {
                    "var": "receiver_name",
                    "value": f"{receiver_name}"
                }
            ]
        }
    ]

    mailer.set_mail_from(mail_from, mail_body)
    mailer.set_mail_to(recipients, mail_body)
    mailer.set_subject(f"Tanween | Invitation Request", mail_body)
    mailer.set_template("zr6ke4n1oqygon12", mail_body)
    mailer.set_simple_personalization(variables, mail_body)

    # mailer.send(mail_body)
    print(mailer.send(mail_body))



def accept_email(requester_email, requester_name, receiver_name):
    api_key = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiMDM1NzM4YjM4MjQzOTM3YzkyNmEyMmMxMjI0OWQ2Njk5NjhhZWY1MmRkNDZjYjJlZGI4MGY4ZTJhZThmYmJmMDA5Y2FmODJmYTg3M2M1ODMiLCJpYXQiOjE2NTg0MzU2NDIuNDAxMjA1LCJuYmYiOjE2NTg0MzU2NDIuNDAxMjA5LCJleHAiOjQ4MTQxMDkyNDIuMzk3ODUxLCJzdWIiOiIzMTc5NyIsInNjb3BlcyI6WyJlbWFpbF9mdWxsIiwiZG9tYWluc19mdWxsIiwiYWN0aXZpdHlfZnVsbCIsImFuYWx5dGljc19mdWxsIiwidG9rZW5zX2Z1bGwiLCJ3ZWJob29rc19mdWxsIiwidGVtcGxhdGVzX2Z1bGwiLCJzdXBwcmVzc2lvbnNfZnVsbCIsInNtc19mdWxsIl19.YC8N_gH3ew2d2qa61S01lpH3_T4JR_vy6Xmg2QP3-4ClQ-qQqjkQ9DGez3EqsmZAg6M37lwNpk9EDrB4ZAu71TCybQ3tsN0IEQJkouSE_JRSYOTl96yRROKgBmHd7HG29QnZL0AojqGyzOG_kYbZQSWEOJLiySFfb4ddWfgLnqY0igCSuBI8EdoSvvafq7jZrq7dBF42H_40w5IolD-8KC9Qdsu0MRv1dPiIUNauNYxc8gHBa4ipH4muzf2sbaUbe2M80NxmsZldTuzHRH9Q2b8heu_JlFTRX_vBTLjJstKw49LA66y2FjuiiDcwN0vIKC45PVfWuzE7G1fRFQfdDWx-vBwp0uks0N1ac16zhhFi96m-uFuRZd9eex3w5C5fv6SDO8yHV9qzw0ld_sbfZxnVFqHP3AlmpYho7XP8eIrhZqmdOQYKiMrIjrxrR2qb_rjrs9QDA_lsNnrfTGdIPGvvmOXLxpgrQflVYDbxH1PCR_9hTNbBpJrcl7L2X7MjeIGaLrngSkudcP1vdFPZGfQpAAhl86zAPzZ5vXt7sLLE4IvyYuTpnFCCebz3UmzkXLhkjYBbglCn4ie0y_L05-4bjkSi-7f_Qo4F6vOkBi_vJZs0q_eU0qK3zwBx5DWiEW27tn-DQnthsASLIiQTo92f33ZX3OxMxkffZeT76f8"
    mailer = emails.NewEmail(api_key)

    # define an empty dict to populate with mail values
    mail_body = {}

    mail_from = {
        "name": "Tanween Platform",
        "email": "info@hackyard.io",
    }

    recipients = [
        {
            "name": requester_name,
            "email": requester_email,
        }
    ]

    variables = [
        {
            "email": requester_email,
            "substitutions": [
                {
                    "var": "requester_name",
                    "value": requester_name
                },
                {
                    "var": "receiver_name",
                    "value": receiver_name
                }
            ]
        }
    ]

    mailer.set_mail_from(mail_from, mail_body)
    mailer.set_mail_to(recipients, mail_body)
    mailer.set_subject("Tanween | Approved Request", mail_body)
    mailer.set_template("pxkjn41mrxp4z781", mail_body)
    mailer.set_simple_personalization(variables, mail_body)

    print(mailer.send(mail_body))



def reject_email(requester_email, requester_name, receiver_name):
    api_key = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiMDM1NzM4YjM4MjQzOTM3YzkyNmEyMmMxMjI0OWQ2Njk5NjhhZWY1MmRkNDZjYjJlZGI4MGY4ZTJhZThmYmJmMDA5Y2FmODJmYTg3M2M1ODMiLCJpYXQiOjE2NTg0MzU2NDIuNDAxMjA1LCJuYmYiOjE2NTg0MzU2NDIuNDAxMjA5LCJleHAiOjQ4MTQxMDkyNDIuMzk3ODUxLCJzdWIiOiIzMTc5NyIsInNjb3BlcyI6WyJlbWFpbF9mdWxsIiwiZG9tYWluc19mdWxsIiwiYWN0aXZpdHlfZnVsbCIsImFuYWx5dGljc19mdWxsIiwidG9rZW5zX2Z1bGwiLCJ3ZWJob29rc19mdWxsIiwidGVtcGxhdGVzX2Z1bGwiLCJzdXBwcmVzc2lvbnNfZnVsbCIsInNtc19mdWxsIl19.YC8N_gH3ew2d2qa61S01lpH3_T4JR_vy6Xmg2QP3-4ClQ-qQqjkQ9DGez3EqsmZAg6M37lwNpk9EDrB4ZAu71TCybQ3tsN0IEQJkouSE_JRSYOTl96yRROKgBmHd7HG29QnZL0AojqGyzOG_kYbZQSWEOJLiySFfb4ddWfgLnqY0igCSuBI8EdoSvvafq7jZrq7dBF42H_40w5IolD-8KC9Qdsu0MRv1dPiIUNauNYxc8gHBa4ipH4muzf2sbaUbe2M80NxmsZldTuzHRH9Q2b8heu_JlFTRX_vBTLjJstKw49LA66y2FjuiiDcwN0vIKC45PVfWuzE7G1fRFQfdDWx-vBwp0uks0N1ac16zhhFi96m-uFuRZd9eex3w5C5fv6SDO8yHV9qzw0ld_sbfZxnVFqHP3AlmpYho7XP8eIrhZqmdOQYKiMrIjrxrR2qb_rjrs9QDA_lsNnrfTGdIPGvvmOXLxpgrQflVYDbxH1PCR_9hTNbBpJrcl7L2X7MjeIGaLrngSkudcP1vdFPZGfQpAAhl86zAPzZ5vXt7sLLE4IvyYuTpnFCCebz3UmzkXLhkjYBbglCn4ie0y_L05-4bjkSi-7f_Qo4F6vOkBi_vJZs0q_eU0qK3zwBx5DWiEW27tn-DQnthsASLIiQTo92f33ZX3OxMxkffZeT76f8"
    mailer = emails.NewEmail(api_key)

    # define an empty dict to populate with mail values
    mail_body = {}

    mail_from = {
        "name": "Tanween Platform",
        "email": "info@hackyard.io",
    }

    recipients = [
        {
            "name": requester_name,
            "email": requester_email,
        }
    ]

    variables = [
        {
            "email": requester_email,
            "substitutions": [
                {
                    "var": "requester_name",
                    "value": requester_name
                },
                {
                    "var": "receiver_name",
                    "value": receiver_name
                }
            ]
        }
    ]

    mailer.set_mail_from(mail_from, mail_body)
    mailer.set_mail_to(recipients, mail_body)
    mailer.set_subject("Tanween | Declined Request", mail_body)
    mailer.set_template("vywj2lpnpzkg7oqz", mail_body)
    mailer.set_simple_personalization(variables, mail_body)

    print(mailer.send(mail_body))