from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from import_export.admin import ImportExportModelAdmin
from preference.models import Preference


@admin.register(Preference)
class PreferenceExportImport(ImportExportModelAdmin):
    list_display = ['id', 'key', 'value']
