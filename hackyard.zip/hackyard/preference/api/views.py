from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from preference.api.serializers import (
    GetAllPreferencesSerializer,
    UpdatePreferencesSerializer
)
from preference.models import Preference
from utils.zoom import generateSignature


# Get all Preferences (beneficiary: Super User)
@api_view(['GET',])
@permission_classes([IsAuthenticated])
def all_preferences(request):
    user = request.user
    data = {}

    if user.is_superuser:
        preferences = Preference.objects.all()[0]
        serializer = GetAllPreferencesSerializer(preferences)
        data = serializer.data
        request_status = status.HTTP_200_OK

    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"
    
    return Response(data = data, status=request_status)



# Update Settings (beneficiary: super user)
@api_view(['PUT',])
@permission_classes([IsAuthenticated])
def update_preferences(request):
    user = request.user
    data = {}
    
    if user.is_superuser:
        try:
            settings = Preference.objects.all().first()
        except:
            data['error'] = "no settings available"
            request_status = status.HTTP_404_NOT_FOUND
            return Response(data, status=request_status)


        serializer = UpdatePreferencesSerializer(settings, data=request.data)
        if serializer.is_valid():
            serializer.save()
            request_status = status.HTTP_200_OK
            data['success'] = "Settings has been updated successfully!"
        else:
            request_status = status.HTTP_400_BAD_REQUEST
            data['error'] = serializer.errors
    
    else:
        request_status = status.HTTP_401_UNAUTHORIZED
        data['error'] = "You are not Authorized to proceed, you need higher permission!"
        
    return Response(data, status=request_status)









# Get all Preferences (beneficiary: Super User)
@api_view(['POST',])
def generate_signature(request):
    
    data = {}
    data['signature'] = generateSignature()
    request_status = status.HTTP_200_OK
    
    return Response(data = data, status=request_status)








# Get Health
@api_view(['GET',])
def get_health(request):
    request_status = status.HTTP_200_OK
    return Response(status=request_status)