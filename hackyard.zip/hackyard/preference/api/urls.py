from django.urls import path
from preference.api.views import all_preferences, generate_signature, update_preferences


urlpatterns = [
    path('', all_preferences, name='all_settings'),
    path('update/', update_preferences, name='update_settings'),
    path('generate-zoom/', generate_signature, name='generate_signature'),
]
