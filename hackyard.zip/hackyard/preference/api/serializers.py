from rest_framework.serializers import ModelSerializer
from rest_framework import serializers
from preference.models import Preference


# Get all Settings
class GetAllPreferencesSerializer(serializers.ModelSerializer):
    # key = serializers.SerializerMethodField()

    # def get_foo(self, obj):
    #     return obj.value['settings']

    class Meta:
        model = Preference
        fields = '__all__'


# Update Settings
class UpdatePreferencesSerializer(serializers.ModelSerializer):

    class Meta:
        model = Preference
        fields = ['value']

# # Post Mentor
# class CreatePreferenceSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Preference
#         fields = '__all__'

# # Update Mentor
# class UpdatePreferenceSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Preference
#         fields = '__all__'
