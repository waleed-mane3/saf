from django.db import models
from django.utils import timezone

def defaultSettings():
    return {"key": "value"}

class Preference(models.Model):

    key = models.CharField(max_length=500, null=True, blank=True)
    value = models.JSONField(default=defaultSettings)

    # this date will never be updated
    created_at = models.DateTimeField(null=True, auto_now_add=True)
    # this date will change every time we update entry
    update_at = models.DateTimeField(null=True, auto_now=True)
